`timescale 1ns/10ps

`include "../syn/netlist/top.v"
`include "../lib/osu018_stdcells.v"

module top_netlist_tb;
    localparam DataWidth = 8;

    localparam TestByte = 8'h35;

    localparam [31:0] SramWrite = 32'h1000_0030;
    localparam [31:0] SramRead  = 32'h1004_0030;

    localparam [31:0] UartTxLoadTdr = 32'h2000_0001;
    localparam [31:0] UartTxLoadTsr = 32'h2000_0002;
    localparam [31:0] UartTxStart   = 32'h2000_0004;

    localparam [31:0] BusIdle = 32'h0000_0000;

    reg clk;
    reg rst_n;

    reg  breq;
    wire bgnt;
    
    wire [31:0] addr_bus;
    wire [7:0]  data_bus;
    wire        ctrl_bus;

    reg [DataWidth-1:0] sram_data;

    wire                uart_txd;
    reg [DataWidth-1:0] uart_data;
    reg                 uart_tx_done;

    integer bit_index;
    integer num_errors;

    top dut(
        .clk_i(clk),
        .rst_ni(rst_n),
        .breq_i(breq),
        .uart_txd_o(uart_txd),
        .bgnt_o(bgnt),
        .addr_bus_io(addr_bus),
        .data_bus_io(data_bus),
        .ctrl_bus_io(ctrl_bus)
    );

    always begin
        #10 clk = !clk;
    end

    initial begin
        clk        = 1'b0;
        rst_n      = 1'b1;
        breq       = 1'b0;
        num_errors = 0;

        force addr_bus = BusIdle;
        force data_bus = 8'hzz;

        // Reset
        #100
        rst_n = 1'b0;

        #100
        rst_n = 1'b1;

        release data_bus;

        // Test request grant
        #100
        breq = 1'b1;

        #20
        if (bgnt === 1'b1) begin
            $display("%4d  PASS: bus granted to the testbench", $time);
        end else begin
            $display("%4d  FAIL: bgnt = %b, expected 1", $time, bgnt);
            num_errors = num_errors + 1;
        end

        breq = 1'b0;

        #20
        if (bgnt === 1'b0) begin
            $display("%4d  PASS: grant released with the request", $time);
        end else begin
            $display("%4d  FAIL: bgnt = %b, expected 0", $time, bgnt);
            num_errors = num_errors + 1;
        end

        // Test SRAM write
        #100
        force addr_bus = SramWrite;
        force data_bus = TestByte;

        #200
        release data_bus;
        force addr_bus = BusIdle;

        // Test SRAM read
        #100
        force addr_bus = SramRead;

        #200
        sram_data = data_bus;
        force addr_bus = BusIdle;

        if (sram_data === TestByte) begin
            $display("%4d  PASS: SRAM returned 0x%h", $time, sram_data);
        end else begin
            $display("%4d  FAIL: SRAM returned 0x%h, expected 0x%h", $time, sram_data, TestByte);
            num_errors = num_errors + 1;
        end

        // Test UART transmission
        #100
        force data_bus = TestByte;
        force addr_bus = UartTxLoadTdr;

        #60
        force addr_bus = UartTxLoadTsr;

        #60
        force addr_bus = UartTxStart;

        #60
        release data_bus;
        force addr_bus = BusIdle;

        #400
        if (uart_tx_done === 1'b1 && uart_data === TestByte) begin
            $display("%4d  PASS: UART transmitted 0x%h", $time, uart_data);
        end else begin
            $display("%4d  FAIL: UART transmitted 0x%h, expected 0x%h", $time, uart_data, TestByte);
            num_errors = num_errors + 1;
        end

        if (num_errors == 0) begin
            $display("%4d  All checks passed", $time);
        end else begin
            $display("%4d  %0d check(s) failed", $time, num_errors);
        end

        #100
        $finish;
    end

    // Sample UART transmission
    initial begin
        uart_tx_done = 1'b0;

        // Sample the start bit
        @(negedge uart_txd);
        @(negedge clk);

        // Sample the payload and the stop bit
        for (bit_index = 0; bit_index < DataWidth; bit_index = bit_index + 1) begin
            @(negedge clk);
            uart_data[bit_index] = uart_txd;
        end

        uart_tx_done = 1'b1;
    end

    initial begin
        $monitor("%4d  addr_bus: 0x%h / data_bus: 0x%h / ctrl_bus: %b / uart_txd: %b",
                 $time, addr_bus, data_bus, ctrl_bus, uart_txd);
    end

    initial begin
        $dumpfile("top_netlist_tb.dump");
        $dumpvars(0, top_netlist_tb);
    end

    initial begin
        $sdf_annotate("../syn/sdf/top.sdf", dut);
    end

endmodule
