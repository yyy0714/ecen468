module sram #(
    parameter AddrWidth = 18,
    parameter DataWidth = 8
) (
    input wire                 ce_ni,
    input wire                 we_ni,
    input wire [AddrWidth-1:0] addr_i,
    input wire [DataWidth-1:0] data_i,
    output reg [DataWidth-1:0] data_o
);

always @(ce_ni or we_ni or addr_i or data_i) begin
    if (!ce_ni && !we_ni) begin
        data_o <= data_i;
    end
end

endmodule
