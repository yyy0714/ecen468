`include "../rtl/_sram.v"
`include "../rtl/uart_tx.v"
`include "../rtl/system_bus_arbiter.v"
`include "../rtl/system_bus_sram_wrapper.v"
`include "../rtl/system_bus_uart_tx_wrapper.v"

module top #(
    parameter AddrWidth = 18,
    parameter DataWidth = 8
) (
    input wire clk_i,
    input wire rst_ni,
    input wire breq_i,

    output wire uart_txd_o,
    output reg  bgnt_o,

    inout wire [31:0] addr_bus_io,
    inout wire [7:0]  data_bus_io,
    inout wire        ctrl_bus_io
);

wire [AddrWidth-1:0] sram_addr;
wire [DataWidth-1:0] sram_data_in;
wire [DataWidth-1:0] sram_data_out;
wire                 sram_ce_n;
wire                 sram_we_n;

wire [DataWidth-1:0] uart_tx_data_in;
wire                 uart_tx_load_tdr;
wire                 uart_tx_load_tsr;
wire                 uart_tx_start;

wire [2:0] system_bus_breq;
wire [2:0] system_bus_bgnt;

assign system_bus_breq[2] = breq_i;

system_bus_arbiter arbiter_inst(
    .breq_i(system_bus_breq),
    .bgnt_o(system_bus_bgnt)
);

sram sram_inst(
    .addr_i(sram_addr),
    .ce_ni(sram_ce_n),
    .we_ni(sram_we_n),
    .data_i(sram_data_in),
    .data_o(sram_data_out)
);

system_bus_sram_wrapper sram_wrapper_inst(
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .data_i(sram_data_out),
    .bgnt_i(system_bus_bgnt[0]),
    .addr_o(sram_addr),
    .ce_no(sram_ce_n),
    .we_no(sram_we_n),
    .data_o(sram_data_in),
    .breq_o(system_bus_breq[0]),
    .addr_bus_io(addr_bus_io),
    .data_bus_io(data_bus_io),
    .ctrl_bus_io(ctrl_bus_io)
);

uart_tx uart_tx_inst(
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .data_bus_i(uart_tx_data_in),
    .load_tdr_i(uart_tx_load_tdr),
    .load_tsr_i(uart_tx_load_tsr),
    .tx_start_i(uart_tx_start),
    .txd_o(uart_txd_o)
);

system_bus_uart_tx_wrapper uart_tx_wrapper_inst(
    .clk_i(clk_i),
    .rst_ni(rst_ni),
    .bgnt_i(system_bus_bgnt[1]),
    .load_tdr_o(uart_tx_load_tdr),
    .load_tsr_o(uart_tx_load_tsr),
    .tx_start_o(uart_tx_start),
    .data_o(uart_tx_data_in),
    .breq_o(system_bus_breq[1]),
    .addr_bus_io(addr_bus_io),
    .data_bus_io(data_bus_io),
    .ctrl_bus_io(ctrl_bus_io)
);

always @(system_bus_bgnt) begin
    bgnt_o = system_bus_bgnt[2];
end

endmodule
