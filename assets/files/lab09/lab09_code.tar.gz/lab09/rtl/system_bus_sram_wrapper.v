module system_bus_sram_wrapper #(
    parameter AddrWidth = 18,
    parameter DataWidth = 8
) (
    input wire                 clk_i,
    input wire                 rst_ni,
    input wire [DataWidth-1:0] data_i,
    input wire                 bgnt_i,

    output reg [AddrWidth-1:0] addr_o,
    output reg                 ce_no,
    output reg                 we_no,
    output reg [DataWidth-1:0] data_o,
    output reg                 breq_o,

    inout wire [31:0]          addr_bus_io,
    inout wire [DataWidth-1:0] data_bus_io,
    inout wire                 ctrl_bus_io
);

reg       bus_free;
reg [3:0] count;

assign ctrl_bus_io = bus_free ? 1'b0 : 1'bz;
assign data_bus_io = bus_free ? ((addr_bus_io[31:28] == 4'b0001 && addr_bus_io[18] == 1'b1)? data_i : 8'hz) : 8'hz;

always @(posedge clk_i) begin
    if (bus_free == 1'b1) begin
        if (addr_bus_io[31:28] == 4'b0001) begin
            // Insert code here
        end
    end
end

always @(posedge clk_i) begin
    if (rst_ni == 1'b0) begin
        breq_o   <= 1'b0;
        bus_free <= 1'b0;
        count    <= 1'b0;

    end else begin
        if (bus_free == 1'b0) begin
            if (bgnt_i == 1'b1) begin
                breq_o   <= 1'b0;
                bus_free <= 1'b1;
                count    <= 1'b1;

            end else if (addr_bus_io[31:28] == 4'b0001) begin
                breq_o   <= 1'b1;
                bus_free <= 1'b0;
                    
            end else begin
                breq_o   <= 1'b0;
                bus_free <= 1'b0;
            end

        end else if (addr_bus_io[31:28] != 4'b0001) begin
            breq_o   <= 1'b0;
            bus_free <= 1'b0;
            count    <= 1'b0;
        end
    end
end

endmodule
