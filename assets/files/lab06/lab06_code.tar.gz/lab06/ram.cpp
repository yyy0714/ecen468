#include <systemc>
#include <sysc/datatypes/int/sc_uint.h>

using namespace sc_core;

SC_MODULE(ram) {
    sc_in<bool>                 ce_ni;
    sc_in<bool>                 we_ni;
    sc_in<sc_dt::sc_uint<18> >   addr_i;
    sc_in<sc_dt::sc_uint<8> >    data_i;
    sc_out<sc_dt::sc_uint<8> >   data_o;

    sc_dt::sc_uint<8> memory[1 << 18];

    void read_memory() {
        if (!ce_ni.read() && we_ni.read()) {
            data_o.write(memory[addr_i.read()]);
        }
    }

    void write_memory() {
        if (!ce_ni.read() && !we_ni.read()) {
            memory[addr_i.read()] = data_i.read();
        }
    }

    SC_CTOR(ram) {
        SC_METHOD(read_memory);
        sensitive << ce_ni << we_ni << addr_i;

        SC_METHOD(write_memory);
        sensitive << ce_ni << we_ni << addr_i << data_i;
    }
};