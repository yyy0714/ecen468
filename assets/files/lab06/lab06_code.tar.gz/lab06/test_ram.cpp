#include <systemc>
#include <scv.h>

#include "ram.cpp"

using namespace sc_core;

// Define a packet
struct Packet{
    sc_uint<18> addr;
    sc_uint<8>  data_in;
    sc_uint<8>  data_out;
};

// Define introspection
SCV_EXTENSIONS(Packet) {
public:
    scv_extensions<sc_uint<18> > addr;
    scv_extensions<sc_uint<8> >  data_in;
    scv_extensions<sc_uint<8> >  data_out;

    SCV_EXTENSIONS_CTOR(Packet) {
        SCV_FIELD(addr);
        SCV_FIELD(data_in);
        SCV_FIELD(data_out);
    }
};

// Define a constraint class
class PacketConstraint : public scv_constraint_base {
public:
    scv_smart_ptr<Packet> p;

    SCV_CONSTRAINT_CTOR(PacketConstraint) {
        // Constrain addr to be less than 10
        SCV_CONSTRAINT( p->addr() < 10 );

        /**
         * TODO: Constrain data_in to be greater than or equal to 80
         */
        

        /**
         * TODO: Constrain data_out to be greater than or equal to 80
         */
    }
};

int sc_main(int argc, char* argv[]) {
  	sc_signal<bool>         ce_sig;
  	sc_signal<bool>         we_sig;
    sc_signal<sc_uint<18> >  addr_sig;
  	sc_signal<sc_uint<8> >   data_in_sig;
  	sc_signal<sc_uint<8> >   data_out_sig;

    ram dut("dut");
    dut.ce_ni(ce_sig);
    dut.we_ni(we_sig);
    dut.addr_i(addr_sig);
    dut.data_i(data_in_sig);
    dut.data_o(data_out_sig);

    sc_trace_file *tf = sc_create_vcd_trace_file("wave");
    sc_trace(tf, ce_sig, "ce_ni");
    sc_trace(tf, we_sig, "we_ni");
    sc_trace(tf, addr_sig, "addr_i");
    sc_trace(tf, data_in_sig, "data_i");
    sc_trace(tf, data_out_sig, "data_o");

    ce_sig.write(1);
    we_sig.write(1);
    sc_start(5, SC_NS);

    PacketConstraint gen("gen");

    // Verification 1
    SC_REPORT_INFO("Testbench", "Verification 1 began");
    for (int i = 0; i < 5; i++) {
        ce_sig.write(0);
        we_sig.write(0);

        gen.next();
        SC_REPORT_INFO("Testbench", "Generated constrained random packets");

        addr_sig.write(gen.p->addr.read());
        data_in_sig.write(gen.p->data_in.read());
        sc_start(3, SC_NS);

        we_sig.write(1);
        sc_start(1, SC_NS);

        gen.p->data_out.write(data_out_sig.read());
        sc_start(1, SC_NS);

        gen.print();
        sc_start(1, SC_NS);
    }
    SC_REPORT_INFO("Testbench", "Verification 1 ended");

    // Verification 2
    SC_REPORT_INFO("Testbench", "Verification 2 began");
    for (int i = 0; i < 5; i++) {
        ce_sig.write(0);
        we_sig.write(0);
        
        scv_bag<std::pair<sc_uint<8>, sc_uint<8> > > range_dist;
        /**
         * TODO: Use scv_bag to generate data_in with the following constraints:
         *       - 5% from 80 to 99
         *       - 95% from 100 to 120
         *
         * Hint: Use scv_bag's add() method to add constraints.
         *
         * Hint: Use std::make_pair() function to construct a std::pair object.
         */

        gen.p->data_in.set_mode(range_dist);
        gen.p->data_in.next();
        SC_REPORT_INFO("Testbench", "Generated constrained random packets");

        data_in_sig.write(gen.p->data_in.read());
        sc_start(1, SC_NS);

        we_sig.write(1);
        sc_start(1, SC_NS);

        gen.p->data_out.write(data_out_sig.read());
        sc_start(1, SC_NS);

        gen.print();
        sc_start(1, SC_NS);
    }
    SC_REPORT_INFO("Testbench", "Verification 2 ended");

    sc_close_vcd_trace_file(tf);

    return 0;
}