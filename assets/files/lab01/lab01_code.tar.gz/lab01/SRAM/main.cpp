#include "RAM.h"
#include "test.h"

int sc_main (int argc, char* argv[]) {
	// Input/Output Signal
  	sc_signal <sc_uint<ADDR_WIDTH>> Addr;
  	sc_signal <bool> 				bWE;
  	sc_signal <bool> 				bCE;
  	sc_signal <sc_uint<DATA_WIDTH>> InData;
  	sc_signal <sc_uint<DATA_WIDTH>> OutData;
  
	sc_clock clk("clk", 1, SC_NS);
	
	// Connect the DUT
	// Method 1. Named Connection
	RAM RAM_01("RAM");
	RAM_01.InData(InData);
	RAM_01.Addr(Addr);
	RAM_01.bCE(bCE);
	RAM_01.bWE(bWE);
	RAM_01.OutData(OutData);
	RAM_01.clk(clk);

	// Method 2. Positional connection
	test TST("TST");
	TST(InData, Addr, bWE, bCE, OutData, clk); // Must have same order of the variables

	// Open VCD file
	sc_trace_file *wf = sc_create_vcd_trace_file("wave");

	// Dump the desired signals
	sc_trace(wf, InData, "InData");
    sc_trace(wf, Addr, "Addr");
	sc_trace(wf, bCE, "bCE");
	sc_trace(wf, bWE, "bWE");
	sc_trace(wf, OutData, "OutData");
	sc_trace(wf, clk, "clk");
	
	// Time to simulate
	// Simulate until it meets sc_stop() if sc_start(-1) or sc_start()
	sc_start(1000, SC_NS);	// Simulate for 1000ns

	// Close the dump file
	sc_close_vcd_trace_file(wf);
	
	return 0;	// Terminate simulation
}
