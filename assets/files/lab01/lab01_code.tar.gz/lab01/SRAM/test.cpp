#include "test.h"

void test::do_test(){
	wait();

	while(true){
		// Write '1' to cell
		for(i=0; i<64; i++){
                	bCE = 0;
                	bWE = 0;
                	InData = i;
                	Addr = i;
                	cout << "@" << sc_time_stamp() << ":: Write mode" << endl;
                	wait(2);
        	}

		// Set to Idle mode
		bCE = 1;
		bWE = 1;
        	InData = 0;
        	cout << "@" << sc_time_stamp() << ":: Set to Idle mode" << endl;
        	wait(2);

        	// Read from cell
        	for(i=0; i<64; i++){
                	bCE = 0;
                	bWE = 1;
                	Addr = i;
                	cout << "@" << sc_time_stamp() << ":: Read mode" << endl;
                	wait(2);
        	}
                sc_stop();
        }
}
