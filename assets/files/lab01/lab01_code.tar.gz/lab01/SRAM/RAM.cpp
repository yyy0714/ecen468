//===========================================
// Function : Asynchronous RAM 
//===========================================
#include "RAM.h"

  // ----- Code Starts Here ----- 
  // Memory Write Block 
  // Write Operation : When we = 1, ce = 1
  

  // Memory Read Block 
  // Read Operation : When we = 0, ce = 1
