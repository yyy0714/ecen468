#include "systemc.h"

#define DATA_WIDTH        8 
#define ADDR_WIDTH        8 
#define RAM_DEPTH         1 << ADDR_WIDTH

SC_MODULE(test){
	// Input/Output Signal
  	sc_out < sc_uint<DATA_WIDTH> > 	InData;
  	sc_out < sc_uint<ADDR_WIDTH> > 	Addr;
  	sc_out < bool > 		bWE;
  	sc_out < bool > 		bCE;
  	sc_in  < sc_uint<DATA_WIDTH> > 	OutData;

	sc_in  < bool > 		clk;

        int i;
	void do_test();

	// Constructor
	SC_CTOR(test) {
          //SC_CTHREAD(do_test, clk.neg());// falling edge of the clk
          SC_CTHREAD(do_test, clk);      // rising or falling edge of the clk
			// Initialize output signals
			bCE.initialize(1);
			bWE.initialize(1);
	}
};
