`timescale 1ns/10ps

`include "../rtl/top.v"

`define NULL            0
`define LEN_BMP_HEADER  54
`define SEEK_SET        0
`define SEEK_CUR        1

`define IMG_0 "../images/references/img_0.bmp"
`define IMG_1 "../images/generated/img_1.bmp"
`define IMG_2 "../images/generated/img_2.bmp"
`define IMG_3 "../images/generated/img_3.bmp"
`define IMG_4 "../images/generated/img_4.bmp"
`define IMG_5 "../images/generated/img_5.bmp"

module top_tb;
    localparam integer DATA_WIDTH = 8;
    localparam integer ADDR_WIDTH = 18;
    localparam integer IMG_WIDTH  = 200;
    localparam integer IMG_HEIGHT = 200;
    localparam integer NUM_PIXELS = IMG_WIDTH * IMG_HEIGHT;

    localparam integer CLK_PERIOD     = 20;
    localparam integer OP_CYCLES      = 10;   // cycles op_enable_n is held low (bus adds latency vs. direct access)
    localparam integer READ_CYCLES    = 4;    // cycles ce_n is held low before a read is sampled
    localparam integer ACQUIRE_CYCLES = 5;    // cycles allowed for a wrapper to win the system bus

    localparam [3:0] ID_MEM   = 4'b0001;      // system-bus device id of the SRAM
    localparam [3:0] ID_CANNY = 4'b0100;      // system-bus device id of the Canny edge detector

    // Base address of each image plane inside the SRAM
    localparam integer BASE_IMG0 = 0 * NUM_PIXELS;
    localparam integer BASE_IMG1 = 1 * NUM_PIXELS;
    localparam integer BASE_IMG2 = 2 * NUM_PIXELS;
    localparam integer BASE_IMG3 = 3 * NUM_PIXELS;
    localparam integer BASE_IMG4 = 4 * NUM_PIXELS;
    localparam integer BASE_IMG5 = 5 * NUM_PIXELS;

    reg                     clk;
    reg                     rst_n;
    reg                     breq;
    wire                    bgnt;
    wire                    uart_txd;

    wire [31:0]             addr_bus;
    wire [DATA_WIDTH-1:0]   data_bus;
    wire                    ctrl_bus;

    reg                     op_enable_n;
    reg  [2:0]              op_mode;
    reg  [3:0]              read_reg_select;
    reg  [3:0]              write_reg_select;

    reg  [31:0]             addr_out;
    reg                     drive_data;
    reg  [DATA_WIDTH-1:0]   data_in;

    top #(
        .AddrWidth   (ADDR_WIDTH),
        .DataWidth   (DATA_WIDTH)
    ) dut (
        .clk_i       (clk),
        .rst_ni      (rst_n),
        .breq_i      (breq),
        .uart_txd_o  (uart_txd),
        .bgnt_o      (bgnt),
        .addr_bus_io (addr_bus),
        .data_bus_io (data_bus),
        .ctrl_bus_io (ctrl_bus)
    );

    assign addr_bus = addr_out;
    assign data_bus = drive_data ? data_in : {DATA_WIDTH{1'bz}};

    reg [7:0]  img_0 [0:NUM_PIXELS-1];
    reg [7:0]  img_1 [0:NUM_PIXELS-1];
    reg [7:0]  img_2 [0:NUM_PIXELS-1];
    reg [7:0]  img_3 [0:NUM_PIXELS-1];
    reg [7:0]  img_4 [0:NUM_PIXELS-1];
    reg [7:0]  img_5 [0:NUM_PIXELS-1];

    reg [31:0] bmp_header [0:12];
    reg [7:0]  img_row    [0:3*IMG_WIDTH-1];

    reg [7:0]  block_x [0:24];
    reg [7:0]  block_y [0:24];
    reg [7:0]  block_z [0:24];
    reg [7:0]  block_o [0:24];

    reg [DATA_WIDTH-1:0] tmp;
    reg [DATA_WIDTH-1:0] t_gradient;
    reg [DATA_WIDTH-1:0] t_direction;

    integer fd;
    integer i;
    integer j;
    integer signed k;
    integer signed l;
    integer m;

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    initial begin
        rst_n            = 1'b0;
        breq             = 1'b0;
        op_enable_n      = 1'b1;
        op_mode          = `MODE_GAUSSIAN;
        read_reg_select  = `REG_GAUSSIAN;
        write_reg_select = `WRITE_BUF_X;
        addr_out         = 32'h0000_0000;
        drive_data       = 1'b0;
        data_in          = {DATA_WIDTH{1'b0}};

        #(2*CLK_PERIOD) rst_n = 1'b1;
    end

    function [31:0] mem_word;
        input [ADDR_WIDTH-1:0] a;
        input                  wen;
        input                  cen;
        begin
            mem_word = {ID_MEM, 8'h00, cen, wen, a};
        end
    endfunction

    function [31:0] canny_word;
        input [2:0] r;
        input [2:0] c;
        input       wen;
        input       cen;
        begin
            canny_word = {ID_CANNY, op_enable_n, op_mode, write_reg_select,
                          read_reg_select, 8'h00, r, c, wen, cen};
        end
    endfunction

    task mem_acquire;
        begin
            drive_data = 1'b0;
            addr_out   = mem_word({ADDR_WIDTH{1'b0}}, 1'b1, 1'b1);
            #(ACQUIRE_CYCLES*CLK_PERIOD);
        end
    endtask

    task canny_acquire;
        begin
            drive_data  = 1'b0;
            op_enable_n = 1'b1;
            addr_out    = canny_word(3'd0, 3'd0, 1'b1, 1'b1);
            #(ACQUIRE_CYCLES*CLK_PERIOD);
        end
    endtask

    task mem_write;
        input [ADDR_WIDTH-1:0] a;
        input [DATA_WIDTH-1:0] d;

        begin
            drive_data = 1'b1;
            data_in    = d;

            addr_out = mem_word(a, 1'b0, 1'b1);
            #(CLK_PERIOD) addr_out = mem_word(a, 1'b0, 1'b0);   // assert ce_n -> SRAM write
            #(CLK_PERIOD) addr_out = mem_word(a, 1'b0, 1'b1);
            #(CLK_PERIOD);
        end
    endtask

    task mem_read;
        input  [ADDR_WIDTH-1:0] a;
        output [DATA_WIDTH-1:0] d;

        begin
            drive_data = 1'b0;

            addr_out = mem_word(a, 1'b1, 1'b1);
            #(CLK_PERIOD)             addr_out = mem_word(a, 1'b1, 1'b0);
            #(READ_CYCLES*CLK_PERIOD) d        = data_bus;
            #(CLK_PERIOD)             addr_out = mem_word(a, 1'b1, 1'b1);
            #(CLK_PERIOD);
        end
    endtask

    task write_data;
        input [2:0]            r;
        input [2:0]            c;
        input [DATA_WIDTH-1:0] d;

        begin
            drive_data = 1'b1;
            data_in    = d;

            addr_out = canny_word(r, c, 1'b0, 1'b1);
            #(CLK_PERIOD) addr_out = canny_word(r, c, 1'b0, 1'b0);
            #(CLK_PERIOD) addr_out = canny_word(r, c, 1'b0, 1'b1);
            #(CLK_PERIOD);
        end
    endtask

    task read_data;
        input  [2:0]            r;
        input  [2:0]            c;
        output [DATA_WIDTH-1:0] d;

        begin
            drive_data = 1'b0;

            addr_out = canny_word(r, c, 1'b1, 1'b1);
            #(CLK_PERIOD)             addr_out = canny_word(r, c, 1'b1, 1'b0);
            #(READ_CYCLES*CLK_PERIOD) d        = data_bus;
            #(CLK_PERIOD)             addr_out = canny_word(r, c, 1'b1, 1'b1);
            #(CLK_PERIOD);
        end
    endtask

    task run_op;
        begin
            drive_data  = 1'b0;

            op_enable_n = 1'b0;
            addr_out    = canny_word(3'd0, 3'd0, 1'b1, 1'b1);
            #(OP_CYCLES*CLK_PERIOD);

            op_enable_n = 1'b1;
            addr_out    = canny_word(3'd0, 3'd0, 1'b1, 1'b1);
            #(CLK_PERIOD);
        end
    endtask

    task load_img_0;
        integer i;
        integer j;
        integer tmp;

        begin
            fd = $fopen(`IMG_0, "rb");
            if (fd == `NULL) begin
                $display("[%12t] ERROR: cannot open '%s'", $time, `IMG_0);
                $finish;
            end

            // Skip the header of the BMP image
            tmp = $fseek(fd, `LEN_BMP_HEADER, `SEEK_SET);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    tmp = $fseek(fd, 2, `SEEK_CUR);
                    img_0[(IMG_HEIGHT-i-1)*IMG_WIDTH + j] = $fgetc(fd);
                end
            end

            $fclose(fd);
        end
    endtask

    task set_bmp_header;
        begin
            bmp_header[0]  = 32'h00_01_d4_f8;
            bmp_header[1]  = 32'h00_00_00_00;
            bmp_header[2]  = 32'h00_00_00_36;
            bmp_header[3]  = 32'h00_00_00_28;
            bmp_header[4]  = 32'h00_00_00_c8;
            bmp_header[5]  = 32'h00_00_00_c8;
            bmp_header[6]  = 32'h00_18_00_01;
            bmp_header[7]  = 32'h00_00_00_00;
            bmp_header[8]  = 32'h00_00_00_00;
            bmp_header[9]  = 32'h00_00_0b_12;
            bmp_header[10] = 32'h00_00_0b_12;
            bmp_header[11] = 32'h00_00_00_00;
            bmp_header[12] = 32'h00_00_00_00;
        end
    endtask

    task write_bmp_header;
        input integer fd;

        integer i;

        begin
            $fwrite(fd, "BM");

            for (i = 0; i < 13; i = i + 1) begin
                $fwrite(fd, "%u", bmp_header[i]);
            end
        end
    endtask

    task write_row;
        input integer fd;

        integer i;

        begin
            for (i = 0; i < (3*IMG_WIDTH)/4; i = i + 1) begin
                $fwrite(fd, "%u", {img_row[i*4+3], img_row[i*4+2], img_row[i*4+1], img_row[i*4+0]});
            end
        end
    endtask

    task write_img_1;
        input integer fd;

        integer i;
        integer j;
        integer idx;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    idx = (IMG_HEIGHT-i-1)*IMG_WIDTH + j;

                    img_row[j*3+0] = img_1[idx];
                    img_row[j*3+1] = img_1[idx];
                    img_row[j*3+2] = img_1[idx];
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_2;
        input integer fd;

        integer i;
        integer j;
        integer idx;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    idx = (IMG_HEIGHT-i-1)*IMG_WIDTH + j;

                    img_row[j*3+0] = img_2[idx];
                    img_row[j*3+1] = img_2[idx];
                    img_row[j*3+2] = img_2[idx];
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_3;
        input integer fd;

        integer i;
        integer j;
        reg [7:0] theta;
        reg [7:0] cr;
        reg [7:0] cg;
        reg [7:0] cb;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    theta = img_3[(IMG_HEIGHT-i-1)*IMG_WIDTH + j];

                    case (theta)
                        0: begin
                            cg = 8'h00;
                            cb = 8'hff;
                            cr = 8'h00;
                        end

                        45: begin
                            cg = 8'h00;
                            cb = 8'h00;
                            cr = 8'hff;
                        end

                        90: begin
                            cg = 8'hff;
                            cb = 8'h00;
                            cr = 8'hff;
                        end

                        135: begin
                            cg = 8'hff;
                            cb = 8'h00;
                            cr = 8'h00;
                        end
                    endcase

                    img_row[j*3+0] = cb;
                    img_row[j*3+1] = cg;
                    img_row[j*3+2] = cr;
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_4;
        input integer fd;

        integer i;
        integer j;
        integer idx;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    idx = (IMG_HEIGHT-i-1)*IMG_WIDTH + j;

                    img_row[j*3+0] = img_4[idx];
                    img_row[j*3+1] = img_4[idx];
                    img_row[j*3+2] = img_4[idx];
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_5;
        input integer fd;

        integer i;
        integer j;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    if (img_5[(IMG_HEIGHT-i-1)*IMG_WIDTH + j] != 0) begin
                        img_row[j*3+0] = 8'hff;
                        img_row[j*3+1] = 8'hff;
                        img_row[j*3+2] = 8'hff;

                    end else begin
                        img_row[j*3+0] = 8'h00;
                        img_row[j*3+1] = 8'h00;
                        img_row[j*3+2] = 8'h00;
                    end
                end

                write_row(fd);
            end
        end
    endtask

    initial begin
        load_img_0;
        set_bmp_header;

        @(posedge rst_n);
        #(ACQUIRE_CYCLES*CLK_PERIOD);

        $display("[%12t] Storing image 0 into the SRAM...", $time);

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_write(BASE_IMG0 + i*IMG_WIDTH + j, img_0[i*IMG_WIDTH + j]);
            end
        end

        // =====================================================================
        // Generate image 1 (smoothed image)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 1...", $time);

        read_reg_select  = `REG_GAUSSIAN;
        write_reg_select = `WRITE_BUF_X;
        op_mode          = `MODE_GAUSSIAN;
        op_enable_n      = 1'b1;

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                if (i < 2 || j < 2 || i >= IMG_HEIGHT-2 || j >= IMG_WIDTH-2) begin
                    // Copy image 0 to image 1
                    mem_acquire;
                    mem_read (BASE_IMG0 + i*IMG_WIDTH + j, tmp);
                    mem_write(BASE_IMG1 + i*IMG_WIDTH + j, tmp);

                end else begin
                    // Read the 5x5 neighbourhood of image 0 from the SRAM
                    mem_acquire;
                    for (k = -2; k <= 2; k = k + 1) begin
                        for (l = -2; l <= 2; l = l + 1) begin
                            mem_read(BASE_IMG0 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_x[(k+2)*5 + (l+2)] = tmp;
                        end
                    end

                    // Stream it through the Canny edge detector
                    canny_acquire;
                    write_reg_select = `WRITE_BUF_X;
                    for (k = -2; k <= 2; k = k + 1) begin
                        for (l = -2; l <= 2; l = l + 1) begin
                            write_data(k+2, l+2, block_x[(k+2)*5 + (l+2)]);
                        end
                    end

                    run_op;

                    read_reg_select = `REG_GAUSSIAN;
                    read_data(3'd0, 3'd0, tmp);

                    // Write image 1
                    mem_acquire;
                    mem_write(BASE_IMG1 + i*IMG_WIDTH + j, tmp);
                end
            end
        end

        // Read image 1 from the SRAM
        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_read(BASE_IMG1 + i*IMG_WIDTH + j, tmp);
                img_1[i*IMG_WIDTH + j] = tmp;
            end
        end

        fd = $fopen(`IMG_1, "wb");
        write_img_1(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_1);

        // =====================================================================
        // Generate image 2 (magnitude) and image 3 (direction)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 2 and image 3...", $time);

        write_reg_select = `WRITE_BUF_X;
        op_mode          = `MODE_SOBEL;
        op_enable_n      = 1'b1;

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_acquire;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            mem_read(BASE_IMG1 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_x[(k+1)*3 + (l+1)] = tmp;
                        end
                    end
                end

                canny_acquire;
                write_reg_select = `WRITE_BUF_X;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            write_data(k+1, l+1, block_x[(k+1)*3 + (l+1)]);
                        end
                    end
                end

                run_op;

                read_reg_select = `REG_GRADIENT;
                read_data(3'd0, 3'd0, t_gradient);

                read_reg_select = `REG_DIRECTION;
                read_data(3'd0, 3'd0, t_direction);

                mem_acquire;
                mem_write(BASE_IMG2 + i*IMG_WIDTH + j, t_gradient);
                mem_write(BASE_IMG3 + i*IMG_WIDTH + j, t_direction);
            end
        end

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_read(BASE_IMG2 + i*IMG_WIDTH + j, tmp);
                img_2[i*IMG_WIDTH + j] = tmp;
            end
        end

        fd = $fopen(`IMG_2, "wb");
        write_img_2(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_2);

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_read(BASE_IMG3 + i*IMG_WIDTH + j, tmp);
                img_3[i*IMG_WIDTH + j] = tmp;
            end
        end

        fd = $fopen(`IMG_3, "wb");
        write_img_3(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_3);

        // =====================================================================
        // Generate image 4 (NMS)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 4...", $time);

        op_mode     = `MODE_NMS;
        op_enable_n = 1'b1;

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_read (BASE_IMG2 + i*IMG_WIDTH + j, tmp);
                mem_write(BASE_IMG4 + i*IMG_WIDTH + j, tmp);
            end
        end

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                // Read the 3x3 magnitude and direction neighbourhoods
                mem_acquire;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            mem_read(BASE_IMG4 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_x[(k+1)*3 + (l+1)] = tmp;
                            mem_read(BASE_IMG3 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_y[(k+1)*3 + (l+1)] = tmp;
                        end
                    end
                end

                canny_acquire;
                write_reg_select = `WRITE_BUF_X;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            write_data(k+1, l+1, block_x[(k+1)*3 + (l+1)]);
                        end
                    end
                end

                write_reg_select = `WRITE_BUF_Y;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            write_data(k+1, l+1, block_y[(k+1)*3 + (l+1)]);
                        end
                    end
                end

                run_op;

                read_reg_select = `REG_NMS;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        read_data(k+1, l+1, tmp);
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            block_o[(k+1)*3 + (l+1)] = tmp;
                        end
                    end
                end

                mem_acquire;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            mem_write(BASE_IMG4 + (i+k)*IMG_WIDTH + (j+l), block_o[(k+1)*3 + (l+1)]);
                        end
                    end
                end
            end
        end

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_read(BASE_IMG4 + i*IMG_WIDTH + j, tmp);
                img_4[i*IMG_WIDTH + j] = tmp;
            end
        end

        fd = $fopen(`IMG_4, "wb");
        write_img_4(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_4);

        // =====================================================================
        // Generate image 5 (hysteresis)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 5...", $time);

        op_mode     = `MODE_HYSTERESIS;
        op_enable_n = 1'b1;

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_write(BASE_IMG5 + i*IMG_WIDTH + j, {DATA_WIDTH{1'b0}});
            end
        end

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                // Read the 3x3 NMS, direction and hysteresis-so-far neighbourhoods
                mem_acquire;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            mem_read(BASE_IMG4 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_x[(k+1)*3 + (l+1)] = tmp;
                            mem_read(BASE_IMG3 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_y[(k+1)*3 + (l+1)] = tmp;
                            mem_read(BASE_IMG5 + (i+k)*IMG_WIDTH + (j+l), tmp);
                            block_z[(k+1)*3 + (l+1)] = tmp;
                        end
                    end
                end

                canny_acquire;
                write_reg_select = `WRITE_BUF_X;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            write_data(k+1, l+1, block_x[(k+1)*3 + (l+1)]);
                        end
                    end
                end

                write_reg_select = `WRITE_BUF_Y;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            write_data(k+1, l+1, block_y[(k+1)*3 + (l+1)]);
                        end
                    end
                end

                write_reg_select = `WRITE_BUF_Z;
                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k >= 0 && i+k < IMG_HEIGHT && j+l >= 0 && j+l < IMG_WIDTH) begin
                            write_data(k+1, l+1, block_z[(k+1)*3 + (l+1)]);
                        end
                    end
                end

                run_op;

                read_reg_select = `REG_HYSTERESIS;
                read_data(3'd0, 3'd0, tmp);

                mem_acquire;
                mem_write(BASE_IMG5 + i*IMG_WIDTH + j, tmp);
            end
        end

        mem_acquire;
        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                mem_read(BASE_IMG5 + i*IMG_WIDTH + j, tmp);
                img_5[i*IMG_WIDTH + j] = tmp;
            end
        end

        fd = $fopen(`IMG_5, "wb");
        write_img_5(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_5);

        $finish;
    end

endmodule
