module system_bus_arbiter #(
    parameter NumRequesters = 4
) (
    input wire [NumRequesters-1:0] breq_i,
    
    output reg [NumRequesters-1:0] bgnt_o
);

always @(breq_i) begin
    bgnt_o[2] <= breq_i[2];				                                // grant signal for test bench (highest priority)
    bgnt_o[0] <= !breq_i[2] && breq_i[0];		                        // grant signal for SRAM
    bgnt_o[1] <= !breq_i[2] && !breq_i[0] && breq_i[1];	                // grant signal for UART transmitter
    bgnt_o[3] <= !breq_i[2] && !breq_i[1] && !breq_i[0] && breq_i[3];   // grant signal for Canny edge detector (lowest priority)
end

endmodule
