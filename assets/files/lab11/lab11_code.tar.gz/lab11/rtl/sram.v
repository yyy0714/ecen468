module sram #(
    parameter AddrWidth = 18,
    parameter DataWidth = 8
) (
    input  wire [AddrWidth-1:0] addr_i,
    input  wire                 ce_ni,
    input  wire                 we_ni,
    input  wire [DataWidth-1:0] data_i,
    output wire [DataWidth-1:0] data_o
);

reg [DataWidth-1:0] mem [0:(1<<AddrWidth)-1];

always @(*) begin
    if (!ce_ni && !we_ni) begin
        mem[addr_i] = data_i;
    end
end

assign data_o = ce_ni ? {DataWidth{1'bz}} : mem[addr_i];

endmodule
