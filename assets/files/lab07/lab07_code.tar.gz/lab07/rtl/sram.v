module sram #(
    parameter AddrWidth = 10,
) (
    input  wire [AddrWidth-1:0] addr_i,
    input  wire                 ce_ni,
    input  wire                 we_ni,
    input  wire [7:0]           data_i,
    output wire [7:0]           data_o
);

    // Declare variables here

    // SRAM Read
    always @(ce_ni or we_ni or addr_i) begin
        // Insert code here
    end

    // SRAM Write
    always @(ce_ni or we_ni or addr_i or data_i) begin
        // Insert code here
    end

endmodule
