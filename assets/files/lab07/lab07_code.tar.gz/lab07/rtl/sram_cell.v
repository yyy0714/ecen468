module sram_cell (
    input  wire cs_ni,
    input  wire we_ni,
    input  wire data_i,
    output wire data_o
);

    // Declare variables here

    always @(*) begin
        // Insert code here
    end

endmodule
