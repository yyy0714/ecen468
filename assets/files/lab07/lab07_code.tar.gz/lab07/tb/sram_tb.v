`timescale 1ns/10ps

`include "../rtl/sram.v"

module sram_tb;

localparam AddrWidth = 18;
localparam DataWidth = 8;

reg  [AddrWidth-1:0] addr;
reg  [DataWidth-1:0] data_i;
wire [DataWidth-1:0] data_o;
reg                  ce_n;
reg                  we_n;

integer i;

sram #(
    .AddrWidth (AddrWidth),
    .DataWidth (DataWidth)
) dut (
    .addr_i (addr),
    .ce_ni  (ce_n),
    .we_ni  (we_n),
    .data_i (data_i),
    .data_o (data_o)
);

initial begin
    ce_n = 1'b1;
    we_n = 1'b1;
end

initial begin
    // Write phase: store data == address for addresses 61..63.
    for (i = 61; i < 64; i = i + 1) begin
    #10 addr = i;
    data_i = i;
    #10 we_n = 1'b0;
    #2  ce_n = 1'b0;
    end
    // Return to idle before reading.
    #2 ce_n = 1'b1;

    // Read phase: read the same addresses back.
    for (i = 61; i < 64; i = i + 1) begin
    #10 addr = i;
    data_i = 8'hxx;
    #10 we_n = 1'b1;
    #2  ce_n = 1'b0;
    end

    #300 $finish;
end

initial begin
    $dumpfile("sram_tb.dump");
    $dumpvars(0, sram_tb);
end

initial begin
    $monitor($time,
            "  READ[%d] WRITE[%d] ENABLE[%d] / ADDR[%d] = data_i:%d / data_o:%d",
            we_n, ~we_n, ~ce_n, addr, data_i, data_o);
end

endmodule
