`timescale 1ns/10ps

`include "../syn/netlist/sram_cell.v"
`include "../lib/osu018_stdcells.v"

module sram_cell_netlist_tb;

reg  cs_n;
reg  we_n;
reg  data_i;
wire data_o;

sram_cell dut (
    .cs_ni  (cs_n),
    .we_ni  (we_n),
    .data_i (data_i),
    .data_o (data_o)
);

initial begin
    cs_n   = 1'b1;
    we_n   = 1'b1;
    data_i = 1'bx;
end

initial begin
    // Write data 1 to the cell.
    #5 data_i = 1'b1;
    #5 cs_n = 1'b0;
    we_n = 1'b0;
    // Deselect the cell (data_o should be high-Z).
    #5 cs_n = 1'b1;
    // Read data from the cell (expect 1).
    #5 cs_n = 1'b0;
    we_n = 1'b1;
    // Write data 0 to the cell.
    #5 data_i = 1'b0;
    #5 cs_n = 1'b0;
    we_n = 1'b0;
    // Deselect the cell (data_o should be high-Z).
    #5 cs_n = 1'b1;
    // Read data from the cell (expect 0).
    #5 cs_n = 1'b0;
    we_n = 1'b1;
    // Deselect the cell (data_o should be high-Z).
    #5 cs_n = 1'b1;

    #50 $finish;
end

initial begin
    $dumpfile("sram_cell_netlist_tb.dump");
    $dumpvars(0, sram_cell_netlist_tb);
end

initial begin
    $monitor($time, "  data_i:%b / data_o:%b / cs_n[%b] / we_n[%b]",
            data_i, data_o, cs_n, we_n);
end

initial begin
    $sdf_annotate("../syn/sdf/sram_cell.sdf", dut);
end

endmodule
