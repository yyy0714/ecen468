`include "../rtl/uart_tx_controller.v"
`include "../rtl/uart_tx_datapath.v"

module uart_tx (
  input       clk_i,
  input       rst_ni,
  input [7:0] data_bus_i,
  input       load_tdr_i, // when asserted, TDR will load data from data bus
  input       load_tsr_i, // when asserted, TSR will load data from TDR
  input       tx_start_i, // when asserted, TSR will start shifting out data
  output      txd_o
);

  // Declare internal variables
  // ...
  // ...

  // Connect uart_tx_controller
  // ...
  // ...

  // Connect uart_tx_datapath
  // ...
  // ...

endmodule
