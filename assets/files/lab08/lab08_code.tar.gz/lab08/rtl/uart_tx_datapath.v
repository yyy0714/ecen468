module uart_tx_datapath (
  input       clk_i,
  input       rst_ni,
  input [7:0] data_bus_i,
  input       tdr_load_i,           // control signal, when asserted, load byte to TDR from data bus
  input       tsr_load_i,           // control signal, when asserted, load byte to TSR from TDR
  input       tsr_set_start_bit_i,  // control signal, when asserted, set start bit in TSR
  input       tsr_shift_bit_i,      // control signal, when asserted, shift one bit out of TSR
  input       reset_i,              // control signal, when asserted, reset TSR and bit counter
  output      tx_busy_o,            // asserted when transmission is in progress
  output      txd_o
);

  reg [7:0] tdr;          // transmit data register
  reg [8:0] tsr;          // transmit shift register
  reg [3:0] bit_counter;  // counts the number of bits transmitted

  assign txd_o = tsr[0];
  assign tx_busy_o = (bit_counter < 9);

  always @(posedge clk_i or negedge rst_ni) begin
    // -----------------------------------
    // Insert your code here.
    // -----------------------------------
  end

endmodule
