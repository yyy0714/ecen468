module uart_tx_controller (
input      clk_i,
input      rst_ni,
input      load_tdr_i,          // when asserted, load byte to TDR from data bus
input      load_tsr_i,          // when asserted, load byte to TSR from TDR
input      tx_start_i,          // when asserted, set start bit in TSR
input      tx_busy_i,           // when asserted, transimission is in progress
output reg tdr_load_o,          // asserted when load_tdr_i is asserted and in state IDLE
output reg tsr_load_o,          // asserted when load_tsr_i is asserted and in state IDLE
output reg tsr_set_start_bit_o, // asserted when tx_start_i is asserted and in state WAIT 
output reg tsr_shift_bit_o,     // asserted when tx_busy_i is asserted and in state SEND
output reg reset_o              // asserted when tx_busy_i is deasserted
);

localparam [2:0] IDLE = 3'b001;
localparam [2:0] WAIT = 3'b010;
localparam [2:0] SEND = 3'b100;

reg [2:0] curr_state;
reg [2:0] next_state;

always @(rst_ni or load_tdr_i or load_tsr_i or tx_start_i or tx_busy_i or curr_state) begin
    // Insert code here
end

always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
        curr_state <= IDLE;
    end else begin
        curr_state <= next_state;
    end
end

endmodule
