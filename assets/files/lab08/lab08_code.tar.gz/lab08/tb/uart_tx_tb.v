`timescale 1ns/10ps

`include "../rtl/uart_tx.v"

module uart_tx_tb;

  integer i;

  wire txd;

  reg       clk;
  reg       rst_n;
  reg [7:0] data_bus;
  reg       load_tdr;
  reg       load_tsr;
  reg       tx_start;

  uart_tx dut (
    .clk_i      (clk),
    .rst_ni     (rst_n),
    .data_bus_i (data_bus),
    .load_tdr_i (load_tdr),
    .load_tsr_i (load_tsr),
    .tx_start_i (tx_start),
    .txd_o      (txd)
  );

  initial begin
    clk      = 1'b0;
    rst_n    = 1'b1;
    load_tdr = 1'b0;
    load_tsr = 1'b0;
    tx_start = 1'b0;
  end

  always begin
    #1 clk = !clk;
  end

  initial begin
    #2 rst_n = 1'b0;
    #6 rst_n = 1'b1;

    for (i = 8'h41; i <= 8'h43; i = i + 1) begin
      #2 data_bus = i;
      #2 load_tdr = 1;
      #2 load_tdr = 0;

      #2 load_tsr = 1;
      #2 load_tsr = 0;

      #6 tx_start = 1;
      #2 tx_start = 0;
      #30;
    end

    $finish;
  end

  initial begin
    $dumpfile("uart_tx_tb.dump");
    $dumpvars(0, uart_tx_tb);
  end

  initial begin
    $monitor("Time: %6t | CLK: %1b | CLK_RST_N: %1b | TX_START: %1b | LOAD_TDR: %1b | LOAD_TSR: %1b | TXD: %1b | DATA_BUS: %8b |",
             $time, clk, rst_n, tx_start, load_tdr, load_tsr, txd, data_bus);
  end

endmodule
