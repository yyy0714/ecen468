`timescale 1ns/10ps

`include "../syn/netlist/uart_tx.v"
`include "../lib/osu018_stdcells.v"

module uart_tx_netlist_tb;

integer i;

wire txd;

reg       clk;
reg       rst_n;
reg [7:0] data_bus;
reg       load_tdr;
reg       load_tsr;
reg       tx_start;

uart_tx dut (
    .clk_i      (clk),
    .rst_ni     (rst_n),
    .data_bus_i (data_bus),
    .load_tdr_i (load_tdr),
    .load_tsr_i (load_tsr),
    .tx_start_i (tx_start),
    .txd_o      (txd)
);

initial begin
    clk      = 1'b0;
    rst_n    = 1'b1;
    load_tdr = 1'b0;
    load_tsr = 1'b0;
    tx_start = 1'b0;
end

always begin
    #1 clk = !clk;
end

initial begin
    #2 rst_n = 1'b0;
    #6 rst_n = 1'b1;

    #2 data_bus = 8'hA7;
    #2 load_tdr = 1;
    #2 load_tdr = 0;

    #2 load_tsr = 1;
    #2 load_tsr = 0;

    #6 tx_start = 1;
    #2 tx_start = 0;
    #30;

    $finish;
end

initial begin
    $dumpfile("uart_tx_netlist_tb.dump");
    $dumpvars(0, uart_tx_netlist_tb);
end

initial begin
    $sdf_annotate("../syn/sdf/uart_tx.sdf", dut);
end

endmodule
