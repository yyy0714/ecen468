//===========================================
// Function : Asynchronous RAM 
//===========================================
#include "SRAM.h"

  // ----- Code Starts Here ----- 
  // Memory Write Block 
  // Write Operation : When we = 1, ce = 1
  void SRAM::write_mem () {
    if (!bCE.read() && !bWE.read()) {
      mem[Addr.read().to_uint()] = InData.read().to_uint();
    }
  }

  // Memory Read Block 
  // Read Operation : When we = 0, ce = 1
  void SRAM::read_mem () {
    if (!bCE.read() && bWE.read())  {
      OutData.write(mem[Addr.read().to_uint()]);
    }
  }
