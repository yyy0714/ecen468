//===========================================
// Function : Asynchronous RAM 
//===========================================
#include "systemc.h"

#define DATA_WIDTH        8 
#define ADDR_WIDTH        18
#define RAM_DEPTH         1 << ADDR_WIDTH

SC_MODULE (SRAM) {
  sc_in_rv <ADDR_WIDTH> Addr    ;
  sc_in    <bool>                 bWE     ;
  sc_in    <bool>                 bCE     ;
  sc_in_rv <DATA_WIDTH> InData  ;
  sc_out_rv <DATA_WIDTH> OutData ;

  // ----- Internal variables -----
  sc_uint <DATA_WIDTH> mem [RAM_DEPTH];

  // ----- Code Starts Here ----- 
  void write_mem ();
  void read_mem (); 

  // ----- Constructor for the SC_MODULE -----
  // sensitivity list
  SC_CTOR(SRAM) {
    SC_METHOD (read_mem);
        sensitive << Addr << bCE << bWE;
    SC_METHOD (write_mem);
        sensitive << Addr << bCE << bWE << InData;
  }
};

