module system_bus_canny_edge_detector_wrapper #(
    parameter DataWidth = 8
) (
    input wire                clk_i;
    input wire                rst_ni;
    input reg [DataWidth-1:0] data_i;
    input wire                bgnt_i;

    output reg                  ce_no;
    output reg                  we_no;
    output reg                  op_enable_no;
    output reg [2:0]            op_mode_o;
    output reg [2:0]            row_o;
    output reg [2:0]            col_o;
    output reg [3:0]            read_reg_select_o;
    output reg [3:0]            write_reg_select_o;
    output wire [DataWidth-1:0] data_o;
    output reg                  breq_o;

    inout wire [31:0]          addr_bus_io,
    inout wire [DataWidth-1:0] data_bus_io,
    inout wire                 ctrl_bus_io
);

reg       bus_free;
reg [3:0] count;

assign ctrl_bus_io = bus_free ? 1'b0 : 1'bz;
assign data_bus_io = bus_free ? ((addr_bus_io[31:28] == 4'b0100 && addr_bus_io[1:0] == 2'b10)? data_i : 8'hzz) : 8'hzz;

always @(posedge clk_i) begin
    if (bus_free == 1'b1) begin
        if (addr_bus_io[31:28] == 4'b0100) begin
            // Insert code here
            //
        end
    end
end

always @(posedge clk_i) begin
    if (rst_ni == 1'b0) begin
        breq_o   <= 1'b0;
        bus_free <= 1'b0;
        count    <= 1'b0;

    end else begin
        if (bus_free == 1'b0) begin
            if (bgnt_i == 1'b1) begin
                breq_o   <= 1'b0;
                bus_free <= 1'b1;
                count    <= 1'b1;

            end else if (addr_bus_io[31:28] == 4'b0100) begin
                breq_o   <= 1'b1;
                bus_free <= 1'b0;
                    
            end else begin
                breq_o   <= 1'b0;
                bus_free <= 1'b0;
            end

        end else if (addr_bus_io[31:28] != 4'b0100) begin
            breq_o   <= 1'b0;
            bus_free <= 1'b0;
            count    <= 1'b0;
        end
    end
end

endmodule
