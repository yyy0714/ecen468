`define MODE_GAUSSIAN   0
`define MODE_SOBEL      1
`define MODE_NMS        2
`define MODE_HYSTERESIS 3

`define REG_GAUSSIAN    0
`define REG_GRADIENT    1
`define REG_DIRECTION   2
`define REG_NMS         3
`define REG_HYSTERESIS  4

`define WRITE_BUF_X     0
`define WRITE_BUF_Y     1
`define WRITE_BUF_Z     2

module canny_edge_detector #(
    parameter DataWidth = 8
) (
    input wire                 clk_i,
    input wire                 rst_ni,
    input wire                 ce_ni,
    input wire                 we_ni,
    input wire                 op_enable_ni,
    input wire [2:0]           op_mode_i,
    input wire [2:0]           row_i,
    input wire [2:0]           col_i,
    input wire [3:0]           read_reg_select_i,
    input wire [3:0]           write_reg_select_i,
    input wire [DataWidth-1:0] data_i,

    output reg [DataWidth-1:0] data_o
);

reg [DataWidth-1:0] buf_x[0:24];
reg [DataWidth-1:0] buf_y[0:24];
reg [DataWidth-1:0] buf_z[0:24];
reg [DataWidth-1:0] gf[0:24];

reg [DataWidth-1:0] sobel_x[0:8];
reg [DataWidth-1:0] sobel_y[0:8];

reg [DataWidth-1:0] tmp_1;
reg [DataWidth-1:0] tmp_2;
reg [DataWidth-1:0] tmp_3;
reg [DataWidth-1:0] tmp_4[0:24];
reg [DataWidth-1:0] tmp_5;

reg        [31:0] gaussian_sum;
reg signed [31:0] gradient_x;
reg signed [31:0] gradient_y;
reg signed [31:0] abs_gradient_x;
reg signed [31:0] abs_gradient_y;
reg signed [1:0]  dx;
reg signed [1:0]  dy;

reg [1:0] state;

localparam THRESHOLD_UPPER = 10;
localparam THRESHOLD_LOWER = 3;

always @(clk_i or rst_ni) begin
    if (!rst_ni) begin
        // Initialize Gaussian filter
        // Insert code here
        //

        // Initialize Sobel kernel x
        // Insert code here
        //

        // Initialize Sobel kernel y
        // Insert code here
        //
    end
end

always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
        state <= 2'b00;

    // Write data
    end else if (ce_ni == 1'b0 && we_ni == 1'b0) begin
        case (write_reg_select_i)
            `WRITE_BUF_X: begin
                buf_x[row_i*5+col_i] <= data_i;
            end
            // Insert code here
            //
        endcase

    // Read data
    end else if (ce_ni == 1'b0 && we_ni == 1'b1) begin
        case (read_reg_select_i)
            `REG_GAUSSIAN: begin
                data_o <= tmp_1;
            end
            // Insert code here
            //
        endcase

    end else begin
        if (op_enable_ni == 1'b0) begin
            case (op_mode_i)
                `MODE_GAUSSIAN: begin
                    case (state)
                        2'b00: begin
                            // Apply Gaussian filter
                            // Insert code here
                            //

                            state <= 2'b01;
                        end

                        2'b01: begin
                            // Divide the result by 128 (hint: right shift)
                            // Insert code here
                            //

                            state <= state;
                        end
                    endcase
                end

                `MODE_SOBEL: begin
                    case (state)
                        2'b00: begin
                            // Calculate gradient
                            // Insert code here
                            //

                            state <= 2'b01;
                        end

                        2'b01: begin
                            // Calculate gradient magnitude (don't forget to divide by 8)
                            // Insert code here
                            //

                            state <= 2'b10;
                        end

                        2'b10: begin
                            // Calcualte gradient direction (step 1)
                            // Insert code here
                            //

                            state <= 2'b11;
                        end

                        2'b11: begin
                            // Calculate gradient direction (step 2)
                            // Insert code here
                            //

                            state <= state;
                        end
                    endcase
                end

                `MODE_NMS: begin
                    case (state)
                        2'b00: begin
                            // Determine dx and dy
                            case (buf_y[6])
                                0: begin
                                    dx <= 1;
                                    dy <= 0;
                                end

                                // Insert code here
                                //
                            endcase

                            state <= 2'b01;
                        end

                        2'b01: begin
                            // Apply non-maximum suppression
                            tmp_4[0]  <= buf_x[0];
                            tmp_4[1]  <= buf_x[1];
                            tmp_4[2]  <= buf_x[2];
                            tmp_4[5]  <= buf_x[5];
                            tmp_4[6]  <= buf_x[6];
                            tmp_4[7]  <= buf_x[7];
                            tmp_4[10] <= buf_x[10];
                            tmp_4[11] <= buf_x[11];
                            tmp_4[12] <= buf_x[12];
                            
                            if (buf_x[6] >= buf_x[6-5*dy-dx] && buf_x[6] >= buf_x[6+5*dy+dx]) begin
                                tmp_4[6-5*dy-dx] <= 0;
                                tmp_4[6+5*dy+dx] <= 0;
                            end else if (buf_x[6] < buf_x[6-5*dy-dx] || buf_x[6] < buf_x[6+5*dy+dx]) begin
                                tmp_4[6] <= 0;
                            end
                            
                            state <= state;
                        end
                    endcase
                end

                `MODE_HYSTERESIS: begin
                    case (state)
                        2'b00: begin
                            // Determine dx and dy
                            case (buf_y[6])
                                0: begin
                                    dx <= 0;
                                    dy <= 1;
                                end

                                45: begin
                                    dx <= 1;
                                    dy <= 1;
                                end

                                90: begin
                                    dx <= 1;
                                    dy <= 0;
                                end

                                135: begin
                                    dx <= 1;
                                    dy <= -1;
                                end
                            endcase

                            state <= 2'b01;
                        end

                        2'b01: begin
                            // The pixel is strong, keep the pixel
                            if (buf_x[6] >= THRESHOLD_UPPER) begin
                                tmp_5 <= 1;

                            // The pixel is weak, discard the pixel
                            end else if (buf_x[6] <= THRESHOLD_LOWER) begin
                                tmp_5 <= 0;

                            // The pixel is a candidate
                            end else begin
                                // The pixel is connected to a strong neighbor, keep the pixel
                                if (buf_x[6-5*dy-dx] >= THRESHOLD_UPPER || buf_x[6+5*dy+dx] >= THRESHOLD_UPPER) begin
                                    tmp_5 <= 1;

                                // The pixel is connected to a candidate that is strong, keep the pixel
                                end else if (buf_z[6-5*dy-dx] == 1 || buf_z[6+5*dy+dx] == 1) begin
                                    tmp_5 <= 1;

                                // Otherwise, discard the pixel
                                end else begin
                                    tmp_5 <= 0;
                                end
                            end

                            state <= state;
                        end
                    endcase
                end
            endcase

        end else begin
            state <= 2'b00;
        end
    end
end

endmodule
