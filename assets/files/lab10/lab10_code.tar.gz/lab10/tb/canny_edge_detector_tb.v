`timescale 1ns/10ps

`include "../rtl/canny_edge_detector.v"

`define NULL            0
`define LEN_BMP_HEADER  54
`define SEEK_SET        0
`define SEEK_CUR        1

`define IMG_0 "../images/references/img_0.bmp"
`define IMG_1 "../images/generated/img_1.bmp"
`define IMG_2 "../images/generated/img_2.bmp"
`define IMG_3 "../images/generated/img_3.bmp"
`define IMG_4 "../images/generated/img_4.bmp"
`define IMG_5 "../images/generated/img_5.bmp"

module canny_edge_detector_tb;
    localparam integer DATA_WIDTH = 8;
    localparam integer IMG_WIDTH  = 200;
    localparam integer IMG_HEIGHT = 200;
    localparam integer NUM_PIXELS = IMG_WIDTH * IMG_HEIGHT;

    localparam integer CLK_PERIOD = 20;
    localparam integer OP_CYCLES  = 5;

    reg                      clk;
    reg                      rst_n;
    reg                      ce_n;
    reg                      we_n;
    reg                      op_enable_n;
    reg  [2:0]               op_mode;
    reg  [2:0]               row;
    reg  [2:0]               col;
    reg  [3:0]               read_reg_select;
    reg  [3:0]               write_reg_select;
    reg  [DATA_WIDTH-1:0]    data_in;
    wire [DATA_WIDTH-1:0]    data_out;

    canny_edge_detector #(
        .DataWidth          (DATA_WIDTH)
    ) dut (
        .clk_i              (clk),
        .rst_ni             (rst_n),
        .ce_ni              (ce_n),
        .we_ni              (we_n),
        .op_enable_ni       (op_enable_n),
        .op_mode_i          (op_mode),
        .row_i              (row),
        .col_i              (col),
        .read_reg_select_i  (read_reg_select),
        .write_reg_select_i (write_reg_select),
        .data_i             (data_in),
        .data_o             (data_out)
    );
    
    reg [7:0]  img_0 [0:NUM_PIXELS-1];
    reg [7:0]  img_1 [0:NUM_PIXELS-1];
    reg [7:0]  img_2 [0:NUM_PIXELS-1];
    reg [7:0]  img_3 [0:NUM_PIXELS-1];
    reg [7:0]  img_4 [0:NUM_PIXELS-1];
    reg [7:0]  img_5 [0:NUM_PIXELS-1];

    reg [31:0] bmp_header [0:12];
    reg [7:0]  img_row    [0:3*IMG_WIDTH-1];

    reg [DATA_WIDTH-1:0] tmp;

    integer fd;
    integer i;
    integer j;
    integer signed k;
    integer signed l;
    integer m;

    initial clk = 1'b0;
    always #(CLK_PERIOD/2) clk = ~clk;

    initial begin
        rst_n            = 1'b0;
        we_n             = 1'b1;
        ce_n             = 1'b1;
        op_enable_n      = 1'b1;
        op_mode          = `MODE_GAUSSIAN;
        row              = 3'd0;
        col              = 3'd0;
        read_reg_select  = `REG_GAUSSIAN;
        write_reg_select = `WRITE_BUF_X;
        data_in          = {DATA_WIDTH{1'b0}};

        #(2*CLK_PERIOD) rst_n = 1'b1;
    end

    task write_data;
        input [2:0]            r;
        input [2:0]            c;
        input [DATA_WIDTH-1:0] d;
        
        begin
            ce_n    = 1'b1;
            row     = r;
            col     = c;
            data_in = d;

            #(CLK_PERIOD) ce_n = 1'b0;
            #(CLK_PERIOD) ce_n = 1'b1;
            #(CLK_PERIOD);
        end
    endtask

    task read_data;
        input  [2:0]            r;
        input  [2:0]            c;
        output [DATA_WIDTH-1:0] d;

        begin
            ce_n = 1'b1;
            row  = r;
            col  = c;

            #(CLK_PERIOD) ce_n = 1'b0;
            #(CLK_PERIOD) d    = data_out;
            #(CLK_PERIOD) ce_n = 1'b1;
            #(CLK_PERIOD);
        end
    endtask

    task load_img_0;
        integer i;
        integer j;
        integer tmp;

        begin
            fd = $fopen(`IMG_0, "rb");
            if (fd == `NULL) begin
                $display("[%12t] ERROR: cannot open '%s'", $time, `IMG_0);
                $finish;
            end

            // Skip the header of the BMP image
            tmp = $fseek(fd, `LEN_BMP_HEADER, `SEEK_SET);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    tmp = $fseek(fd, 2, `SEEK_CUR);                       // skip blue + green
                    img_0[(IMG_HEIGHT-i-1)*IMG_WIDTH + j] = $fgetc(fd);   // keep red
                end
            end

            $fclose(fd);
        end
    endtask

    task set_bmp_header;
        begin
            bmp_header[0]  = 32'h00_01_d4_f8;
            bmp_header[1]  = 32'h00_00_00_00;
            bmp_header[2]  = 32'h00_00_00_36;
            bmp_header[3]  = 32'h00_00_00_28;
            bmp_header[4]  = 32'h00_00_00_c8;
            bmp_header[5]  = 32'h00_00_00_c8;
            bmp_header[6]  = 32'h00_18_00_01;
            bmp_header[7]  = 32'h00_00_00_00;
            bmp_header[8]  = 32'h00_00_00_00;
            bmp_header[9]  = 32'h00_00_0b_12;
            bmp_header[10] = 32'h00_00_0b_12;
            bmp_header[11] = 32'h00_00_00_00;
            bmp_header[12] = 32'h00_00_00_00;
        end
    endtask

    task write_bmp_header;
        input integer fd;

        integer i;

        begin
            $fwrite(fd, "BM");

            for (i = 0; i < 13; i = i + 1) begin
                $fwrite(fd, "%u", bmp_header[i]);
            end
        end
    endtask

    task write_row;
        input integer fd;

        integer i;

        begin
            for (i = 0; i < (3*IMG_WIDTH)/4; i = i + 1) begin
                $fwrite(fd, "%u", {img_row[i*4+3], img_row[i*4+2], img_row[i*4+1], img_row[i*4+0]});
            end
        end
    endtask

    task write_img_1;
        input integer fd;

        integer i;
        integer j;
        integer idx;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    idx = (IMG_HEIGHT-i-1)*IMG_WIDTH + j;

                    img_row[j*3+0] = img_1[idx];
                    img_row[j*3+1] = img_1[idx];
                    img_row[j*3+2] = img_1[idx];
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_2;
        input integer fd;

        integer i;
        integer j;
        integer idx;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    idx = (IMG_HEIGHT-i-1)*IMG_WIDTH + j;

                    img_row[j*3+0] = img_2[idx];
                    img_row[j*3+1] = img_2[idx];
                    img_row[j*3+2] = img_2[idx];
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_3;
        input integer fd;

        integer i;
        integer j;
        reg [7:0] theta;
        reg [7:0] cr;
        reg [7:0] cg;
        reg [7:0] cb;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    theta = img_3[(IMG_HEIGHT-i-1)*IMG_WIDTH + j];

                    case (theta)
                        0: begin
                            cg = 8'h00;
                            cb = 8'hff;
                            cr = 8'h00;
                        end

                        45: begin
                            cg = 8'h00;
                            cb = 8'h00;
                            cr = 8'hff;
                        end

                        90: begin
                            cg = 8'hff;
                            cb = 8'h00;
                            cr = 8'hff;
                        end

                        135: begin
                            cg = 8'hff;
                            cb = 8'h00;
                            cr = 8'h00;
                        end
                    endcase

                    img_row[j*3+0] = cb;
                    img_row[j*3+1] = cg;
                    img_row[j*3+2] = cr;
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_4;
        input integer fd;

        integer i;
        integer j;
        integer idx;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    idx = (IMG_HEIGHT-i-1)*IMG_WIDTH + j;

                    img_row[j*3+0] = img_4[idx];
                    img_row[j*3+1] = img_4[idx];
                    img_row[j*3+2] = img_4[idx];
                end

                write_row(fd);
            end
        end
    endtask

    task write_img_5;
        input integer fd;

        integer i;
        integer j;

        begin
            write_bmp_header(fd);

            for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
                for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                    if (img_5[(IMG_HEIGHT-i-1)*IMG_WIDTH + j] != 0) begin
                        img_row[j*3+0] = 8'hff;
                        img_row[j*3+1] = 8'hff;
                        img_row[j*3+2] = 8'hff;

                    end else begin
                        img_row[j*3+0] = 8'h00;
                        img_row[j*3+1] = 8'h00;
                        img_row[j*3+2] = 8'h00;
                    end
                end

                write_row(fd);
            end
        end
    endtask

    initial begin
        for (i = 0; i < NUM_PIXELS; i = i + 1) begin
            img_2[i] = 8'h00;
            img_3[i] = 8'h00;
            img_5[i] = 8'h00;
        end

        load_img_0;
        set_bmp_header;

        // =====================================================================
        // Generate image 1 (blurred image)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 1...", $time);

        read_reg_select  = `REG_GAUSSIAN;
        write_reg_select = `WRITE_BUF_X;
        op_mode          = `MODE_GAUSSIAN;
        op_enable_n      = 1'b1;

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                if (i < 2 || j < 2 || i >= IMG_HEIGHT-2 || j >= IMG_WIDTH-2) begin
                    img_1[i*IMG_WIDTH+j] = img_0[i*IMG_WIDTH+j];

                end else begin
                    we_n = 1'b0;
                    ce_n  = 1'b1;

                    for (k = -2; k <= 2; k = k + 1) begin
                        for (l = -2; l <= 2; l = l + 1) begin
                            write_data(k+2, l+2, img_0[(i+k)*IMG_WIDTH+(j+l)]);
                        end
                    end

                    // Run the operation
                    ce_n = 1'b1;
                    we_n = 1'b1;
                    #(CLK_PERIOD)           op_enable_n = 1'b0;
                    #(OP_CYCLES*CLK_PERIOD) op_enable_n = 1'b1;

                    // Read the image
                    ce_n = 1'b1;
                    we_n = 1'b1;

                    read_data(3'd0, 3'd0, tmp);
                    img_1[i*IMG_WIDTH+j] = tmp;
                end
            end
        end

        fd = $fopen(`IMG_1, "wb");
        write_img_1(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_1);

        // =====================================================================
        // Generate image 2 (gradient image) and image 3 (direction image)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 2 and image 3...", $time);

        write_reg_select = `WRITE_BUF_X;
        op_mode          = `MODE_SOBEL;
        op_enable_n      = 1'b1;

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                we_n = 1'b0;
                ce_n  = 1'b1;
                #(CLK_PERIOD);

                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        if (i+k < 0 || j+l < 0 || i+k >= IMG_HEIGHT || j+l >= IMG_WIDTH) begin
                            data_in = {DATA_WIDTH{1'b0}};
                        end else begin
                            write_data(k+1, l+1, img_1[(i+k)*IMG_WIDTH+(j+l)]);
                        end
                    end
                end

                // Run the operation
                ce_n = 1'b1;
                we_n = 1'b1;
                #(CLK_PERIOD)           op_enable_n = 1'b0;
                #(OP_CYCLES*CLK_PERIOD) op_enable_n = 1'b1;

                // Read the image
                ce_n = 1'b1;
                we_n = 1'b1;

                read_reg_select = `REG_GRADIENT;
                read_data(3'd0, 3'd0, tmp);
                img_2[i*IMG_WIDTH+j] = tmp;

                read_reg_select = `REG_DIRECTION;
                read_data(3'd0, 3'd0, tmp);
                img_3[i*IMG_WIDTH+j] = tmp;
            end
        end

        fd = $fopen(`IMG_2, "wb");
        write_img_2(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_2);

        fd = $fopen(`IMG_3, "wb");
        write_img_3(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_3);

        // =====================================================================
        // Generate image 4 (NMS image)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 4...", $time);

        op_mode     = `MODE_NMS;
        op_enable_n = 1'b1;

        for (i = 0; i < NUM_PIXELS; i = i + 1) begin
            img_4[i] = img_2[i];
        end

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                for (k = 0; k < 2; k = k + 1) begin
                    case (k)
                        0: write_reg_select = `WRITE_BUF_X;
                        1: write_reg_select = `WRITE_BUF_Y;
                    endcase

                    we_n = 1'b0;
                    ce_n  = 1'b1;
                    #(CLK_PERIOD);

                    for (l = -1; l <= 1; l = l + 1) begin
                        for (m = -1; m <= 1; m = m + 1) begin
                            if (i+l < 0 || j+m < 0 || i+l >= IMG_HEIGHT || j+m >= IMG_WIDTH) begin
                                data_in = {DATA_WIDTH{1'b0}};
                            end else if (k == 0) begin
                                write_data(l+1, m+1, img_4[(i+l)*IMG_WIDTH+(j+m)]);
                            end else if (k == 1) begin
                                write_data(l+1, m+1, img_3[(i+l)*IMG_WIDTH+(j+m)]);
                            end
                        end
                    end
                end

                // Run the operation
                ce_n = 1'b1;
                we_n = 1'b1;
                #(CLK_PERIOD)           op_enable_n = 1'b0;
                #(OP_CYCLES*CLK_PERIOD) op_enable_n = 1'b1;

                // Read the image
                ce_n = 1'b1;
                we_n = 1'b1;
                read_reg_select = `REG_NMS;

                for (k = -1; k <= 1; k = k + 1) begin
                    for (l = -1; l <= 1; l = l + 1) begin
                        read_data(k+1, l+1, tmp);

                        if (!(i+k < 0 || j+l < 0 || i+k >= IMG_HEIGHT || j+l >= IMG_WIDTH)) begin
                            img_4[(i+k)*IMG_WIDTH+(j+l)] = tmp;
                        end
                    end
                end
            end
        end

        fd = $fopen(`IMG_4, "wb");
        write_img_4(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_4);

        // =====================================================================
        // Generating image 5 (hysteresis image)
        // =====================================================================
        #(OP_CYCLES*CLK_PERIOD);
        $display("[%12t] Generating image 5...", $time);

        op_mode     = `MODE_HYSTERESIS;
        op_enable_n = 1'b1;

        for (i = 0; i < IMG_HEIGHT; i = i + 1) begin
            for (j = 0; j < IMG_WIDTH; j = j + 1) begin
                for (k = 0; k < 3; k = k + 1) begin
                    case (k)
                        0: write_reg_select = `WRITE_BUF_X;
                        1: write_reg_select = `WRITE_BUF_Y;
                        2: write_reg_select = `WRITE_BUF_Z;
                    endcase

                    we_n = 1'b0;
                    ce_n = 1'b1;
                    #(CLK_PERIOD);

                    for (l = -1; l <= 1; l = l + 1) begin
                        for (m = -1; m <= 1; m = m + 1) begin
                            if (i+l < 0 || j+m < 0 || i+l >= IMG_HEIGHT || j+m >= IMG_WIDTH) begin
                                data_in = {DATA_WIDTH{1'b0}};
                            end else if (k == 0) begin
                                write_data(l+1, m+1, img_4[(i+l)*IMG_WIDTH+(j+m)]);
                            end else if (k == 1) begin
                                write_data(l+1, m+1, img_3[(i+l)*IMG_WIDTH+(j+m)]);
                            end else if (k == 2) begin
                                write_data(l+1, m+1, img_5[(i+l)*IMG_WIDTH+(j+m)]);
                            end
                        end
                    end
                end

                // Run the operation
                ce_n = 1'b1;
                we_n = 1'b1;
                #(CLK_PERIOD)           op_enable_n = 1'b0;
                #(OP_CYCLES*CLK_PERIOD) op_enable_n = 1'b1;
                
                // Read the image
                ce_n = 1'b1;
                we_n = 1'b1;
                read_reg_select = `REG_HYSTERESIS;

                read_data(3'd0, 3'd0, tmp);
                img_5[i*IMG_WIDTH+j] = tmp;
            end
        end

        fd = $fopen(`IMG_5, "wb");
        write_img_5(fd);
        $fclose(fd);
        $display("[%12t] Generated %s", $time, `IMG_5);

        $finish;
    end

endmodule
