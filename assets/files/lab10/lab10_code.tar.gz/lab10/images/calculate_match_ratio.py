from PIL import Image
import numpy as np

def calculate_match_ratio(img1_path, img2_path):
    img1 = Image.open(img1_path)
    img2 = Image.open(img2_path)

    if img1.size != img2.size:
        raise ValueError("Images do not have the same dimensions")

    img1_data = np.array(img1)
    img2_data = np.array(img2)

    total_pixels = img1_data.size

    matching_pixels = np.sum(img1_data == img2_data)

    matching_ratio = matching_pixels / total_pixels

    # print(f"Total pixels of {img2_path}: {total_pixels}")
    # print(f"Matching pixels of {img2_path}: {matching_pixels}")
    print(f"Matching ratio of {img2_path}: {matching_ratio:.2%}")

calculate_match_ratio("generated/img_1.bmp", "references/img_1.bmp")
calculate_match_ratio("generated/img_2.bmp", "references/img_2.bmp")
calculate_match_ratio("generated/img_3.bmp", "references/img_3.bmp")
calculate_match_ratio("generated/img_4.bmp", "references/img_4.bmp")
calculate_match_ratio("generated/img_5.bmp", "references/img_5.bmp")
